package com.sambit.week2mvn.mvnrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvnrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
