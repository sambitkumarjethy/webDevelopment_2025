package com.sambit.week2mvn.mvnrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvnrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvnrestapiApplication.class, args);
	}

}
